function bannerAnimation(){
    var tl = new TimelineMax({ repeat: 2, repeatDelay: 3, });

    TweenMax.set([ copy1, bottomshape,  optlogo, logo],  {opacity: 1, });
    TweenMax.set([cta ],  { opacity: 1, scale: 0, transformOrigin: "115px 23px" });
    TweenMax.set([product],  {x: 200, opacity: 1 });
    TweenMax.set([offer ],  { opacity: 1, scale: 0, transformOrigin: "228px 33px" });
    TweenMax.set([copy1, price1, price2],  {y: 50, opacity: 1 });


    // TweenMax.to(copy1, 0.5, { x:0, opacity: 1, ease: Quad.easeOut, delay: 0 });
    // TweenMax.to(price1, 0.5, { x:0, opacity: 1, ease: Quad.easeOut, delay: 0.5 });
    // TweenMax.to(price2, 0.5, { x:0, opacity: 1, ease: Quad.easeOut, delay: 0.75 });
    // TweenMax.to(product, 0.5, { x:0, opacity: 1, ease: Quad.easeOut, delay: 1 });
    
    // TweenMax.to([offer], 0.65, { scale: 1, ease: Back.easeOut, delay: 1.5 });
    // TweenMax.to([cta], 0.65, { scale: 1, ease: Back.easeOut, delay: 2.25 });



     tl.to(copy1, 0.5, { y: 0, ease: Quad.easeOut })
      .to(price1, 0.5, { y: 0, ease: Quad.easeOut })
      .to(price2, 0.5, { y: 0, ease: Quad.easeOut },)
      .to(product, 0.5, { x: 0, ease: Quad.easeOut })
      .to(offer, 0.65, { scale: 1, ease: Back.easeOut })
      .to(cta, 0.65, { scale: 1, ease: Back.easeOut });
}

function exitbanner() {
    window.open(clickTag, "_blank");
}

function mouseOvers(){
    TweenMax.to(cta, 0.35, { scale: 1.15, ease: Quad.easeOut, delay: 0 });
    TweenMax.to(cta, 0.5, { scale: 1, ease: Quad.easeOut, delay: 0.25 });

}
function mouseleaves(){
    TweenMax.to(cta, 0.5, { scale: 1.15, ease: Quad.easeOut, delay: 0 });
    TweenMax.to(cta, 0.35, { scale: 1, ease: Quad.easeOut,  delay: 0.25 });
}

function startBanner(){
    var clickelement = document.getElementById("banner");
    clickelement.addEventListener("click", exitbanner);
    bannerAnimation();
}


window.addEventListener("load", startBanner);
